package com.xin.domain;

import java.sql.Date;
import java.util.LinkedHashSet;
import java.util.Set;

/*
 * 订单类
 */
public class Trade {
	//Trade 对象对应的 id
	private Integer tradeId;
	
	//交易的时间
	private Date tradeTime;
	
	//Trade 关联的多个 TradeItem
	private Set<TradeItem> set = new LinkedHashSet<>();
	
	//和 Trade 关联的 User 的 userId
	private Integer userId;

	public Trade() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Trade(Integer tradeId, Date tradeTime, Set<TradeItem> set,
			Integer userId) {
		super();
		this.tradeId = tradeId;
		this.tradeTime = tradeTime;
		this.set = set;
		this.userId = userId;
	}

	public Integer getTradeId() {
		return tradeId;
	}

	public void setTradeId(Integer tradeId) {
		this.tradeId = tradeId;
	}

	public Date getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}

	public Set<TradeItem> getSet() {
		return set;
	}

	public void setSet(Set<TradeItem> set) {
		this.set = set;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Trade [tradeId=" + tradeId + ", tradeTime=" + tradeTime
				+ ", set=" + set + ", userId=" + userId + "]";
	}
	
	
	
	
}
