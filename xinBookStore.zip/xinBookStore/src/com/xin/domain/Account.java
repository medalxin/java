package com.xin.domain;


/*
 * 用户账户类
 */
public class Account {
	
	private Integer accountId;
	
	private float balance;

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(Integer accountId, float balance) {
		super();
		this.accountId = accountId;
		this.balance = balance;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", balance=" + balance + "]";
	}
	
	
}
