package com.xin.test;

import org.junit.Test;

import com.xin.dao.UserDao;
import com.xin.dao.impl.UserDaoImpl;
import com.xin.domain.User;

public class UserDaoTest {
	private UserDao userDao = new UserDaoImpl();
	
	@Test
	public void testGetUser(){
		User user = userDao.getUser("AAA");
		System.out.print(user);
		
		
	}
}
