package com.xin.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xin.domain.User;
import com.xin.service.UserService;
import com.xin.service.ipml.UserServiceImpl;

public class UserServlet extends HttpServlet {
	private UserService userService = new UserServiceImpl();
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = req.getParameter("username");
		
		if(username!= null||"".equals(username)){
			User user = userService.getUserByUserName(username);
			if(user!=null){
				req.setAttribute("user", user);
				req.getRequestDispatcher("/servlet/bookServlet?method=getBooks").forward(req, resp);
				//resp.sendRedirect(req.getContextPath()+"/servlet/bookServlet?method=getBooks");
				
			}else{
				resp.sendRedirect(req.getContextPath()+"/index.jsp");
			}
			
		}else{
			resp.sendRedirect(req.getContextPath()+"/index.jsp");
		}
		
		
	}
	
	

}
