package com.xin.dao;

import com.xin.domain.User;

/*
 * 
 * 用户类接口
 */
public interface UserDao {
	//根据用户名获取接口
	/**
	 * 根据用户名获取 User 对象
	 * @param username
	 * @return
	 */
	public abstract User getUser(String username);
		
}
