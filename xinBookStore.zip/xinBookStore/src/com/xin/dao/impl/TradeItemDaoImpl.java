package com.xin.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.xin.dao.TradeItemDao;
import com.xin.domain.TradeItem;

public class TradeItemDaoImpl extends BaseDao<TradeItem> implements TradeItemDao {
	
	@Override
	public Set<TradeItem> getTradeItemWithTradeId(Integer tradeId) {
		// TODO Auto-generated method stub
		String sql = "select * from tradeitem where tradeid = ?";
		
		return new HashSet<>(queryForList(sql, tradeId));
	}

	@Override
	public void batchSave(Collection<TradeItem> items) {
		// TODO Auto-generated method stub
		String sql = "insert into tradeitem(bookid, quantity, tradeid) values(?, ?, ?)";
		
		Object[][] params = new Object[items.size()][3];
		List<TradeItem> list = new ArrayList<>(items);
		for(int i = 0; i < list.size();i++){
			params[i][0] = list.get(i).getBookId();
			params[i][1] = list.get(i).getQuantity();
			params[i][2] = list.get(i).getTradeId();
		}
		batch(sql, params);
		
	}

}
