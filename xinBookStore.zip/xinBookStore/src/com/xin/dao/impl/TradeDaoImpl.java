package com.xin.dao.impl;


import java.util.LinkedHashSet;
import java.util.Set;

import com.xin.dao.TradeDao;
import com.xin.domain.Trade;

public class TradeDaoImpl extends BaseDao<Trade> implements TradeDao {

	@Override
	public Set<Trade> getTradesWithUserId(Integer userId) {
		// TODO Auto-generated method stub
		String sql = "select * from trade where userid = ? order by tradetime desc";
		return new LinkedHashSet<>(queryForList(sql, userId));
	}

	@Override
	public void insert(Trade trade) {
		// TODO Auto-generated method stub
		String sql = "insert into trade(userid, datetime) values(?, ?)";
		long tradeid = insert(sql, trade.getUserId(),trade.getTradeTime());
		trade.setTradeId((int)tradeid);
	}

}
