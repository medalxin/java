package com.xin.dao.impl;

import com.xin.dao.UserDao;
import com.xin.domain.User;

public class UserDaoImpl extends BaseDao<User> implements UserDao {

	@Override
	public User getUser(String username) {
		// TODO Auto-generated method stub
		String sql = "select * from userinfo where username = ?";
		
		User user = query(sql, username);
		return user;
	}

}
