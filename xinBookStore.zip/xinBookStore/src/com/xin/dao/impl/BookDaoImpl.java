package com.xin.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.xin.dao.BookDao;
import com.xin.domain.Book;
import com.xin.domain.ShoppingCartItem;
import com.xin.web.CriteriaBook;
import com.xin.web.Page;

public class BookDaoImpl extends BaseDao<Book> implements BookDao{

	@Override
	public Book getBook(int id) {
		// TODO Auto-generated method stub
		String sql = "select * from mybooks where id = ?";
		return query(sql, id);
	}

	@Override
	public Page<Book> getPage(CriteriaBook cb) {
		// TODO Auto-generated method stub
		Page<Book> page = new Page<>(cb.getPageNo());
		page.setTotalItemNumber(getTotalBookNumber(cb));
		
		//校验 pageNo 的合法性
		
		cb.setPageNo(page.getPageNo());
		page.setList(getPageList(cb, 4));
		
		return page;
	}

	@Override
	public long getTotalBookNumber(CriteriaBook cb) {
		// TODO Auto-generated method stub
		
		String sql = "select count(*) from mybooks where price >= ? and price <= ?";
		
		return  getSingleValue(sql, cb.getMinPrice(),cb.getMaxPrice());
		 
	}
	
	//2. 
		/**
		 * MySQL 分页使用 LIMIT, 其中 fromIndex 从 0 开始。 
		 */
	
	@Override
	public List<Book> getPageList(CriteriaBook cb, int pageSize) {
		
		String sql = "select * from mybooks where price >= ? and price <= ? limit ?, ?";
		return queryForList(sql, cb.getMinPrice(),cb.getMaxPrice(),(cb.getPageNo()-1)*pageSize, pageSize);
		
	}

	@Override
	public int getStoreNumber(Integer id) {
		// TODO Auto-generated method stub
		String sql ="select storenumber from mybooks where id = ?";
		return getSingleValue(sql, id);
	}

	@Override
	public void batchUpdateStoreNumberAndSalesAmount(
			Collection<ShoppingCartItem> items) {
		
		String sql = "update mybooks set storenumber = storenumber - ? , salesAmount = salesAmount + ? where id = ?";
		
		Object[][] params = null;
		params = new Object[items.size()][3];
		List<ShoppingCartItem> list = new ArrayList<>(items);
		
		for(int i = 0; i<items.size(); i++){
			params[i][0] = list.get(i).getQuantity();
			params[i][1] = list.get(i).getQuantity();
			params[i][2] = list.get(i).getBook().getId();
			
		}
		batch(sql, params);
		
	}

}
