package com.xin.dao.impl;

import com.xin.dao.AccountDao;
import com.xin.domain.Account;

public class AccountDaoImpl extends BaseDao<Account> implements AccountDao {

	
	@Override
	public void updateBalance(Integer accountId, float amount) {
		// TODO Auto-generated method stub
		String sql = "update account set balance = balance - ? where accountid = ?";
		update(sql, accountId, amount);

	}

	@Override
	public Account getAccountWithId(Integer id) {
		// TODO Auto-generated method stub
		String sql = "select * from account where accountid = ?";
		
		return query(sql, id);
	}

}
