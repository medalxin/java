package com.xin.web;

import java.sql.Connection;

/*
 * 获取数据链接和线程绑定
 */
public class ConnectionContext {
	
	//数据链接上下文
	private static ConnectionContext instance = new ConnectionContext();
	
	//线程集合
	private ThreadLocal<Connection> ConnectionThreadLocal = new ThreadLocal<Connection>();
	
	private ConnectionContext() {
		
	}
	
	public static ConnectionContext getInstance(){
		return instance;
	}
	
	public void bind(Connection conn){
		ConnectionThreadLocal.set(conn);
	}
	
	public Connection get(){
		return ConnectionThreadLocal.get();
	}
	
	public void remove(){
		ConnectionThreadLocal.remove();
	}
	
}
