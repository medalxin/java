package com.xin.service;

import com.xin.domain.User;

public interface UserService {
	
	public abstract User getUserByUserName(String username);
	
	public abstract User getUserWithTrades(String Username);
	
}
