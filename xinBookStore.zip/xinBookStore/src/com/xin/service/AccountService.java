package com.xin.service;

import com.xin.domain.Account;

public interface AccountService {
	
	public abstract  Account getAccountWithId(Integer accountId);
	
}
