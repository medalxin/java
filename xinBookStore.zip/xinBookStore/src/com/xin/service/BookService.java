package com.xin.service;



import com.xin.domain.Book;
import com.xin.domain.ShoppingCart;
import com.xin.web.CriteriaBook;
import com.xin.web.Page;

public interface BookService {
	public abstract Page<Book> getPage(CriteriaBook cb);
	
	public abstract Book getBook(int id);
	
	public abstract boolean addToCart(int id, ShoppingCart sc);
	
	public abstract void removeItemFromShoppingCart(ShoppingCart sc, int id);
	
	public abstract void clearShoppingCart(ShoppingCart sc);
	
	public abstract void updateItemQuantity(ShoppingCart sc, int id, int quantity);
	
	public abstract void cash(ShoppingCart shoppingCart, String username,
			String accountId);
}
