package com.xin.service.ipml;

import java.sql.Date;


import java.util.ArrayList;
import java.util.Collection;

import com.xin.dao.AccountDao;
import com.xin.dao.BookDao;
import com.xin.dao.TradeDao;
import com.xin.dao.TradeItemDao;
import com.xin.dao.UserDao;
import com.xin.dao.impl.AccountDaoImpl;
import com.xin.dao.impl.BookDaoImpl;
import com.xin.dao.impl.TradeDaoImpl;
import com.xin.dao.impl.TradeItemDaoImpl;
import com.xin.dao.impl.UserDaoImpl;
import com.xin.domain.Book;
import com.xin.domain.ShoppingCart;
import com.xin.domain.ShoppingCartItem;
import com.xin.domain.Trade;
import com.xin.domain.TradeItem;
import com.xin.service.BookService;
import com.xin.web.CriteriaBook;
import com.xin.web.Page;



public class BookServiceImpl implements BookService {
	
	private BookDao bookDao = new BookDaoImpl();
	
	
	
	private AccountDao accountDao = new AccountDaoImpl(); 
	
	private UserDao userDao = new UserDaoImpl();
	
	private TradeDao tradeDao = new TradeDaoImpl();
	
	private TradeItemDao tradeItemDao = new TradeItemDaoImpl();
	
	@Override
	public Page<Book> getPage(CriteriaBook cb) {
		// TODO Auto-generated method stub
		return bookDao.getPage(cb);
	}

	@Override
	public Book getBook(int id) {
		// TODO Auto-generated method stub
		return bookDao.getBook(id);
	}

	@Override
	public boolean addToCart(int id, ShoppingCart sc) {
		// TODO Auto-generated method stub
		Book book = bookDao.getBook(id);
		if(book!=null){
			sc.addBooks(book);
			return true;
		}
		
		return false;
	}

	@Override
	public void removeItemFromShoppingCart(ShoppingCart sc, int id) {
		// TODO Auto-generated method stub
		sc.removeItem(id);
	}

	@Override
	public void clearShoppingCart(ShoppingCart sc) {
		// TODO Auto-generated method stub
		sc.clear();
	}

	@Override
	public void updateItemQuantity(ShoppingCart sc, int id, int quantity) {
		// TODO Auto-generated method stub
		sc.updateItemQuantity(id, quantity);
		
	}

	@Override
	public void cash(ShoppingCart shoppingCart, String username,
			String accountId) {
		// TODO Auto-generated method stub
		
		//1. 更新 mybooks 数据表相关记录的 salesamount 和 storenumber
		bookDao.batchUpdateStoreNumberAndSalesAmount(shoppingCart.getItems());
		
		//2. 更新 account 数据表的 balance
		accountDao.updateBalance(Integer.parseInt(accountId), shoppingCart.getTotalMoney());
		
		//3. 向 trade 数据表插入一条记录
		Trade trade = new Trade();
		trade.setUserId(userDao.getUser(username).getUserId());
		trade.setTradeTime(new Date((new java.util.Date()).getTime()));
		tradeDao.insert(trade);
		
		//4. 向 tradeitem 数据表插入 n 条记录
		Collection<TradeItem> items = new ArrayList<>();
		for(ShoppingCartItem sci: shoppingCart.getItems()){
			TradeItem tradeItem = new TradeItem();
			
			tradeItem.setBookId(sci.getBook().getId());
			tradeItem.setQuantity(sci.getQuantity());
			tradeItem.setTradeId(trade.getTradeId());
			
			items.add(tradeItem);
		}
		tradeItemDao.batchSave(items);
		
		//5. 清空购物车
		shoppingCart.clear();
		
	}

}
