package com.xin.service.ipml;

import com.xin.dao.TradeDao;
import com.xin.dao.UserDao;
import com.xin.dao.impl.TradeDaoImpl;
import com.xin.dao.impl.TradeItemDaoImpl;
import com.xin.dao.impl.UserDaoImpl;
import com.xin.domain.User;
import com.xin.service.UserService;

public class UserServiceImpl implements UserService {
	
	private UserDao userDao = new UserDaoImpl();
	
	private TradeDao tradeDao = new TradeDaoImpl();
	
	@Override
	public User getUserByUserName(String username) {
		// TODO Auto-generated method stub
		User user = userDao.getUser(username);
		
		return user;
	}



	@Override
	public User getUserWithTrades(String Username) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
