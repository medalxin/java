package com.xin.service.ipml;

import com.xin.dao.AccountDao;
import com.xin.dao.impl.AccountDaoImpl;
import com.xin.domain.Account;
import com.xin.service.AccountService;

public class AccountServiceImpl implements AccountService {
	
	private AccountDao accountDao = new AccountDaoImpl();
	
	@Override
	public Account getAccountWithId(Integer accountId) {
		// TODO Auto-generated method stub
		return accountDao.getAccountWithId(accountId);
	}

}
