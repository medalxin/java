package com.xin.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.xin.exception.DBException;

/**
 * 
 * JDBC 的工具类
 *
 */

public class JDBCUtils {
	private static DataSource dataSource = null;
	
	static{
		dataSource = new ComboPooledDataSource("javawebapp");
	}
	
	//获取数据库连接
	public static Connection getConnection(){
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DBException("数据库连接错误!");
		}
		return conn;
	}
	
	//关闭数据库连接
	public static void close(Connection conn){
		
		try {
			if(conn != null){
				conn.close();
			}
		} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new DBException("数据库连接错误!");
		}
		
	}
	
	
	//关闭数据库连接
		public static void close(ResultSet rs, Statement statement){
			try {
				if(rs != null){
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new DBException("数据库连接错误!");
			}
			
			try {
				if(statement != null){
					statement.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new DBException("数据库连接错误!");
			}
		}
	
}
